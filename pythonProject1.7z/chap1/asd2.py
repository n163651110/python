# 学习
# 加油
print('hello\nworld')
print('hello\tworld')
print('helloooo\tworld')
print('hello\rworld')
print('hello\bworld')
print('http:\\\\www.baidu.com')
print('老师说：\'大家好\'')
print(r'hello\nworld')
print(r'hello\nworld')
print(r'hello\nworld\\')