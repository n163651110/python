print('helloworld')
print(520)
print(6+4-5)
#可以说出一个数字。
print('4.6+1')





fp=open('C:/text.txt','a+')
print('helloworld',file=fp)
fp.close()

print('fghyfgg','ggggh','ggugg')