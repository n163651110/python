# 学习
# 加油
name='玛利亚'
print(name)
name='楚溜冰'
print(name)
