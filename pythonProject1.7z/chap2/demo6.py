# 学习
# 加油
f1=True
f2=False
print(f1,type(f1))
print(f2,type(f2))
#布尔值可以转换成整数计算
print(f1+1)    #2 1+1的结果为2 trueb表示1
print(f2+1)    #1 0+1的结果为1 False表示0


a