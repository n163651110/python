# 学习
# 加油
import keyword
print(keyword.kwlist)
