# 学习
# 加油
name='玛利亚'
print(name)
print(name)
print('标识',id(name))
print('类型',type(name))
print('值',name)
