print(chr(0b100111001011000))
print(ord('乘'))