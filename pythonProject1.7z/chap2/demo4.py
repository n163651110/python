# 学习
# 加油
n1=90
n2=-76
n3=0
print(n1,type(n1))
print(n2,type(n2))
print(n3,type(n3))

print('十进制',118)
print('二进制',0b10101111)#二进制0b开头
print('八进制',0o176)#八进制0o开头
print('十六进制',0x1eaf)#十六进制0x开头